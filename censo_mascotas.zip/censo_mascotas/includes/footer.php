    </div> <!-- Cierre del container -->
    
    <footer class="mt-5 py-3 bg-light">
        <div class="container text-center">
            <img src="<?php echo BASE_URL; ?>/img/logo_ayuntamiento.png" alt="Logo Ayuntamiento" height="50">
            <p class="mt-2 mb-0">Sistema de Censo de Mascotas</p>
            <p class="text-muted">Ayuntamiento de San Andrés Cholula &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>