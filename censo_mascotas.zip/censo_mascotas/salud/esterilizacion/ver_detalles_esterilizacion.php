<?php
require_once __DIR__ . '/../../config.php';
require_once BASE_PATH . '/database/conexion.php';
require_once BASE_PATH . '/includes/funciones.php';
requerir_autenticacion();

// Validar ID de esterilización
$id_esterilizacion = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id_esterilizacion <= 0) {
    redirigir_con_mensaje(BASE_URL . '/buscar.php', 'danger', 'Registro no especificado');
}

// Obtener datos de la esterilización
try {
    $stmt = $conn->prepare("SELECT e.*, m.nombre AS nombre_mascota, m.edad AS edad_mascota, m.genero AS genero_mascota, 
                          m.especie AS especie_mascota, m.raza AS raza_mascota, m.foto_ruta AS foto_mascota,
                          t.nombre AS nombre_tutor, t.apellido_paterno, t.apellido_materno, t.telefono, 
                          t.calle, t.numero_exterior, t.numero_interior, t.colonia, t.codigo_postal
                          FROM esterilizaciones e
                          JOIN mascotas m ON e.id_mascota = m.id_mascota
                          JOIN tutores t ON e.id_tutor = t.id_tutor
                          WHERE e.id_esterilizacion = ?");
    $stmt->bind_param("i", $id_esterilizacion);
    $stmt->execute();
    $registro = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$registro) {
        redirigir_con_mensaje(BASE_URL . '/buscar.php', 'danger', 'Registro no encontrado');
    }

    $page_title = "Esterilización - " . htmlspecialchars($registro['nombre_mascota']);
    include(BASE_PATH . '/includes/header.php');

} catch (Exception $e) {
    registrar_error($e->getMessage());
    redirigir_con_mensaje(BASE_URL . '/buscar.php', 'danger', 'Error al cargar datos');
}
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">
            <i class="fas fa-cut me-2"></i> Detalles de Esterilización
        </h2>
        <div class="d-flex gap-2">
            <div class="dropdown">
                <button class="btn btn-purple dropdown-toggle" type="button" id="dropdownReportes" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-file-pdf me-1"></i> Generar Reporte
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownReportes">
                    <li><a class="dropdown-item" href="#" onclick="generarReporte('responsiva')">Responsiva de Esterilización</a></li>
                    <li><a class="dropdown-item" href="#" onclick="generarReporte('historia')">Historia Clínica</a></li>
                    <li><a class="dropdown-item" href="#" onclick="generarReporte('hoja')">Hoja de Tratamiento</a></li>
                </ul>
            </div>
            <a href="<?= BASE_URL ?>/salud/salud_animal.php?id=<?= $registro['id_mascota'] ?>" class="btn btn-outline-purple">
                <i class="fas fa-arrow-left me-1"></i> Volver
            </a>
        </div>
    </div>

    <!-- Tarjeta de información básica -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <span>Información básica</span>
            <span class="badge bg-purple">
                <?= htmlspecialchars($registro['tipo_procedimiento']) ?>
            </span>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="info-label">Mascota</div>
                    <div class="info-value">
                        <?= htmlspecialchars($registro['nombre_mascota']) ?>
                        <?php if (!empty($registro['foto_mascota'])): ?>
                            <img src="<?= htmlspecialchars($registro['foto_mascota']) ?>" class="img-thumbnail mt-2" style="max-height: 150px;" alt="Foto de la mascota">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-label">Fecha</div>
                    <div class="info-value"><?= date('d/m/Y', strtotime($registro['fecha_procedimiento'])) ?></div>
                    
                    <div class="info-label">Hora</div>
                    <div class="info-value"><?= date('H:i', strtotime($registro['hora_procedimiento'])) ?></div>
                </div>
                <div class="col-md-4">
                    <div class="info-label">Responsable</div>
                    <div class="info-value"><?= htmlspecialchars($registro['responsable']) ?></div>
                    
                    <div class="info-label">Localidad</div>
                    <div class="info-value"><?= htmlspecialchars($registro['localidad']) ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección Tutor -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0">Datos del Tutor</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="info-label">Nombre</div>
                    <div class="info-value">
                        <?= htmlspecialchars($registro['nombre_tutor'] . ' ' . $registro['apellido_paterno'] . ' ' . ($registro['apellido_materno'] ?? '')) ?>
                    </div>
                    
                    <div class="info-label">Teléfono</div>
                    <div class="info-value"><?= htmlspecialchars($registro['telefono']) ?></div>
                </div>
                <div class="col-md-6">
                    <div class="info-label">Domicilio</div>
                    <div class="info-value">
                        <?= htmlspecialchars($registro['calle'] . ' ' . $registro['numero_exterior']) ?>
                        <?= !empty($registro['numero_interior']) ? 'Int. ' . htmlspecialchars($registro['numero_interior']) : '' ?>,
                        <?= htmlspecialchars($registro['colonia']) ?>, CP <?= htmlspecialchars($registro['codigo_postal']) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección Mascota -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0">Datos de la Mascota</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="info-label">Nombre</div>
                    <div class="info-value"><?= htmlspecialchars($registro['nombre_mascota']) ?></div>
                    
                    <div class="info-label">Especie</div>
                    <div class="info-value"><?= htmlspecialchars($registro['especie_mascota']) ?></div>
                </div>
                <div class="col-md-4">
                    <div class="info-label">Género</div>
                    <div class="info-value"><?= htmlspecialchars($registro['genero_mascota']) ?></div>
                    
                    <div class="info-label">Edad</div>
                    <div class="info-value"><?= htmlspecialchars($registro['edad_mascota']) ?> años</div>
                </div>
                <div class="col-md-4">
                    <div class="info-label">Raza</div>
                    <div class="info-value"><?= htmlspecialchars($registro['raza_mascota'] ?? 'No especificada') ?></div>
                    
                    <div class="info-label">Vacunación</div>
                    <div class="info-value">
                        <?= $registro['vacunacion_rabia'] ? 'Rabia, ' : '' ?>
                        <?= $registro['vacunacion_basica'] ? 'Básica' : 'No registrada' ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección Historial Clínico -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0">Historial Clínico</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="info-label">Desparasitación</div>
                    <div class="info-value">
                        <?= !empty($registro['desparasitacion_producto']) ? 
                            htmlspecialchars($registro['desparasitacion_producto']) . 
                            (!empty($registro['desparasitacion_fecha']) ? ' ('.date('d/m/Y', strtotime($registro['desparasitacion_fecha'])).')' : '') : 
                            'No registrada' ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-label">Antecedentes</div>
                    <div class="info-value"><?= !empty($registro['antecedentes']) ? nl2br(htmlspecialchars($registro['antecedentes'])) : 'No registrados' ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección Constantes Fisiológicas -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0">Constantes Fisiológicas</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <div class="info-label">FR (resp/min)</div>
                    <div class="info-value"><?= htmlspecialchars($registro['fr_respiratoria'] ?? 'N/A') ?></div>
                </div>
                <div class="col-md-3">
                    <div class="info-label">FC (lat/min)</div>
                    <div class="info-value"><?= htmlspecialchars($registro['fc_cardiaca'] ?? 'N/A') ?></div>
                </div>
                <div class="col-md-3">
                    <div class="info-label">CC (1-5)</div>
                    <div class="info-value"><?= htmlspecialchars($registro['cc_capilar'] ?? 'N/A') ?></div>
                </div>
                <div class="col-md-3">
                    <div class="info-label">TLLC (seg)</div>
                    <div class="info-value"><?= htmlspecialchars($registro['tllc'] ?? 'N/A') ?></div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-3">
                    <div class="info-label">Reflejo Tusígeno</div>
                    <div class="info-value"><?= htmlspecialchars($registro['reflejo_tusigeno'] ?? 'N/A') ?></div>
                </div>
                <div class="col-md-3">
                    <div class="info-label">Reflejo Deglutorio</div>
                    <div class="info-value"><?= htmlspecialchars($registro['reflejo_deglutorio'] ?? 'N/A') ?></div>
                </div>
                <div class="col-md-3">
                    <div class="info-label">Mucosas</div>
                    <div class="info-value"><?= htmlspecialchars($registro['mucosas'] ?? 'N/A') ?></div>
                </div>
                <div class="col-md-3">
                    <div class="info-label">Temperatura (°C)</div>
                    <div class="info-value"><?= htmlspecialchars($registro['temperatura'] ?? 'N/A') ?></div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="info-label">Nódulos Linfáticos</div>
                    <div class="info-value"><?= htmlspecialchars($registro['nodulos_linfaticos'] ?? 'N/A') ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección Datos Quirúrgicos -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0">Datos Quirúrgicos</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="info-label">Plan Anestésico</div>
                    <div class="info-value"><?= htmlspecialchars($registro['plan_anestesico'] ?? 'N/A') ?></div>
                </div>
                <div class="col-md-8">
                    <div class="info-label">Medicación Preoperatoria</div>
                    <div class="info-value"><?= !empty($registro['medicacion_previa']) ? nl2br(htmlspecialchars($registro['medicacion_previa'])) : 'N/A' ?></div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="info-label">Observaciones Quirúrgicas</div>
                    <div class="info-value"><?= !empty($registro['observaciones_quirurgicas']) ? nl2br(htmlspecialchars($registro['observaciones_quirurgicas'])) : 'N/A' ?></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sección Postoperatorio -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0">Cuidados Postoperatorios</h5>
        </div>
        <div class="card-body">
            <div class="info-label">Cuidados Postoperatorios</div>
            <div class="info-value"><?= !empty($registro['cuidados_postoperatorios']) ? nl2br(htmlspecialchars($registro['cuidados_postoperatorios'])) : 'N/A' ?></div>
            
            <div class="info-label mt-3">Medicación Postoperatoria</div>
            <div class="info-value"><?= !empty($registro['medicacion_postoperatoria']) ? nl2br(htmlspecialchars($registro['medicacion_postoperatoria'])) : 'N/A' ?></div>
        </div>
    </div>

    <!-- Sección de firma digital -->
    <?php if ($registro['firma_imagen']): ?>
    <div class="card shadow-sm">
        <div class="card-header bg-light">
            Consentimiento firmado
        </div>
        <div class="card-body">
            <div class="firma-container">
                <img src="<?= BASE_URL . htmlspecialchars($registro['firma_imagen']) ?>" alt="Firma digital" class="firma-img">
                <div class="mb-2"><strong>Firmado por:</strong> <?= htmlspecialchars($registro['nombre_firmante']) ?></div>
                <div class="mb-2"><strong>DNI:</strong> <?= htmlspecialchars($registro['dni_firmante']) ?></div>
                <div class="text-muted small">Fecha de firma: <?= date('d/m/Y H:i', strtotime($registro['fecha_firma'])) ?></div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
function generarReporte(tipo) {
    // Esta función se implementará más adelante para generar PDFs
    alert(`Generando reporte en formato ${tipo}. Esta función se implementará próximamente.`);
    // window.location.href = `generar_pdf.php?id=<?= $id_esterilizacion ?>&tipo=${tipo}`;
}
</script>

<style>
    .info-label {
        font-weight: 500;
        color: #6c757d;
        margin-bottom: 0.25rem;
    }
    .info-value {
        font-size: 1rem;
        margin-bottom: 1rem;
        padding: 0.5rem;
        background-color: #f8f9fa;
        border-radius: 4px;
        border-left: 3px solid #8b0180;
    }
    .firma-container {
        border: 1px dashed #ccc;
        padding: 1rem;
        margin-top: 1rem;
        text-align: center;
    }
    .firma-img {
        max-width: 300px;
        max-height: 100px;
        margin-bottom: 1rem;
    }
    .badge.bg-purple {
        background-color: #8b0180;
        color: white;
    }
    .btn-purple {
        background-color: #8b0180;
        color: white;
    }
    .btn-purple:hover {
        background-color: #6a015f;
    }
    .btn-outline-purple {
        border-color: #8b0180;
        color: #8b0180;
    }
    .btn-outline-purple:hover {
        background-color: #8b0180;
        color: white;
    }
</style>

<?php include(BASE_PATH . '/includes/footer.php'); ?>