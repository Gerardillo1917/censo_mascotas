<?php
require_once __DIR__ . '/../../config.php';
require_once BASE_PATH . '/database/conexion.php';
require_once BASE_PATH . '/includes/funciones.php';
requerir_autenticacion();

// Validar ID de mascota
$id_mascota = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id_mascota <= 0) {
    redirigir_con_mensaje('buscar.php', 'danger', 'Mascota no especificada');
}

// Obtener datos de mascota y tutor
try {
    $stmt = $conn->prepare("SELECT m.*, t.*, t.id_tutor 
                          FROM mascotas m 
                          JOIN tutores t ON m.id_tutor = t.id_tutor 
                          WHERE m.id_mascota = ?");
    $stmt->bind_param("i", $id_mascota);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $datos = $resultado->fetch_assoc();
    $stmt->close();

    if (!$datos) {
        redirigir_con_mensaje('buscar.php', 'danger', 'Registro no encontrado');
    }
} catch (Exception $e) {
    registrar_error($e->getMessage());
    redirigir_con_mensaje('buscar.php', 'danger', 'Error al cargar datos');
}

$page_title = "Esterilización - " . htmlspecialchars($datos['nombre']);
include(BASE_PATH . '/includes/header.php');

// Datos del usuario
$nombre_usuario = $_SESSION['nombre_completo'] ?? 'Usuario no identificado';
$fecha_actual = date('Y-m-d');
$hora_actual = date('H:i');
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0 text-purple">
            <i class="fas fa-cut me-2"></i> Registro de Esterilización
        </h2>
        <a href="<?= BASE_URL ?>/salud/salud_animal.php?id=<?= $id_mascota ?>" class="btn btn-outline-purple">
            <i class="fas fa-arrow-left me-1"></i> Volver
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-purple text-white">
            <h5 class="mb-0"><?= htmlspecialchars($datos['nombre']) ?> - <?= htmlspecialchars($datos['especie']) ?> <?= htmlspecialchars($datos['genero']) ?></h5>
        </div>
        
        <div class="card-body">
            <form method="post" action="<?= BASE_URL ?>/salud/esterilizacion/procesar_esterilizacion.php" id="formEsterilizacion">
                <input type="hidden" name="id_mascota" value="<?= $id_mascota ?>">
                <input type="hidden" name="id_tutor" value="<?= $datos['id_tutor'] ?>">
                
                <!-- Sección 1: Datos del tutor y mascota -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">1. Datos del Tutor y Mascota</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-label">Tutor</div>
                                <div class="info-value"><?= htmlspecialchars($datos['nombre'] . ' ' . $datos['apellido_paterno'] . ' ' . $datos['apellido_materno']) ?></div>
                                
                                <div class="info-label">Domicilio</div>
                                <div class="info-value">
                                    <?= htmlspecialchars($datos['calle'] . ' ' . $datos['numero_exterior']) ?>
                                    <?= !empty($datos['numero_interior']) ? 'Int. ' . htmlspecialchars($datos['numero_interior']) : '' ?>,
                                    <?= htmlspecialchars($datos['colonia']) ?>, CP <?= htmlspecialchars($datos['codigo_postal']) ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-label">Teléfono</div>
                                <div class="info-value"><?= htmlspecialchars($datos['telefono']) ?></div>
                                
                                <div class="info-label">Mascota</div>
                                <div class="info-value">
                                    <?= htmlspecialchars($datos['nombre']) ?>, 
                                    <?= htmlspecialchars($datos['edad']) ?> años, 
                                    <?= htmlspecialchars($datos['raza'] ?? 'Sin raza especificada') ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección 2: Datos del procedimiento -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">2. Información del Procedimiento</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Fecha*</label>
                                    <input type="date" class="form-control" name="fecha_procedimiento" value="<?= $fecha_actual ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Hora*</label>
                                    <input type="time" class="form-control" name="hora_procedimiento" value="<?= $hora_actual ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Tipo de procedimiento*</label>
                                    <select class="form-select" name="tipo_procedimiento" required>
                                        <option value="Ovario Histerectomía">Ovario Histerectomía</option>
                                        <option value="Orquiectomía">Orquiectomía</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Responsable*</label>
                                    <input type="text" class="form-control" name="responsable" value="<?= htmlspecialchars($nombre_usuario) ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
    <label class="form-label">Localidad*</label>
    <select class="form-select" name="localidad" required>
        <option value="" disabled selected>Selecciona una localidad</option>
        <option value="Cabecera Municipal de San Andrés Cholula" <?= (($_SESSION['campana_lugar'] ?? '') == 'Cabecera Municipal de San Andrés Cholula') ? 'selected' : '' ?>>Cabecera Municipal de San Andrés Cholula</option>
        <option value="San Antonio Cacalotepec" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Antonio Cacalotepec') ? 'selected' : '' ?>>San Antonio Cacalotepec</option>
        <option value="San Bernardino Tlaxcalancingo" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Bernardino Tlaxcalancingo') ? 'selected' : '' ?>>San Bernardino Tlaxcalancingo</option>
        <option value="San Francisco Acatepec" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Francisco Acatepec') ? 'selected' : '' ?>>San Francisco Acatepec</option>
        <option value="San Luis Tehuiloyocan" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Luis Tehuiloyocan') ? 'selected' : '' ?>>San Luis Tehuiloyocan</option>
        <option value="San Rafael Comac" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Rafael Comac') ? 'selected' : '' ?>>San Rafael Comac</option>
        <option value="Santa María Tonantzintla" <?= (($_SESSION['campana_lugar'] ?? '') == 'Santa María Tonantzintla') ? 'selected' : '' ?>>Santa María Tonantzintla</option>
        <option value="San Felipe Cuapexco" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Felipe Cuapexco') ? 'selected' : '' ?>>San Felipe Cuapexco</option>
        <option value="San Juan Cuautlancingo" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Juan Cuautlancingo') ? 'selected' : '' ?>>San Juan Cuautlancingo</option>
        <option value="Santa María Malacatepec" <?= (($_SESSION['campana_lugar'] ?? '') == 'Santa María Malacatepec') ? 'selected' : '' ?>>Santa María Malacatepec</option>
        <option value="San Antonio Mihuacán" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Antonio Mihuacán') ? 'selected' : '' ?>>San Antonio Mihuacán</option>
        <option value="San Bernardino Chalchihuapan" <?= (($_SESSION['campana_lugar'] ?? '') == 'San Bernardino Chalchihuapan') ? 'selected' : '' ?>>San Bernardino Chalchihuapan</option>
        <option value="Clínica de Salud Animal del Municipio de San Andrés Cholula" <?= (($_SESSION['campana_lugar'] ?? '') == 'Clínica de Salud Animal del Municipio de San Andrés Cholula') ? 'selected' : '' ?>>Clínica de Salud Animal del Municipio de San Andrés Cholula</option>
    </select>
</div>

                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección 3: Historial Clínico -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">3. Historial Clínico</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="vacunacion_rabia" name="vacunacion_rabia" value="1">
                                    <label class="form-check-label" for="vacunacion_rabia">Vacunación contra Rabia</label>
                                </div>
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="vacunacion_basica" name="vacunacion_basica" value="1">
                                    <label class="form-check-label" for="vacunacion_basica">Cuadro Básico de Vacunación</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Desparasitación (Producto)</label>
                                    <input type="text" class="form-control" name="desparasitacion_producto">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Fecha Desparasitación</label>
                                    <input type="date" class="form-control" name="desparasitacion_fecha">
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Antecedentes</label>
                                <textarea class="form-control" name="antecedentes" rows="3" placeholder="Enfermedades anteriores, cirugías, procedencia..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección 4: Constantes fisiológicas -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">4. Constantes Fisiológicas</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">FR (resp/min)</label>
                                <input type="text" class="form-control" name="fr_respiratoria">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">FC (lat/min)</label>
                                <input type="text" class="form-control" name="fc_cardiaca">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">CC (1-5)</label>
                                <input type="text" class="form-control" name="cc_capilar">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">TLLC (seg)</label>
                                <input type="text" class="form-control" name="tllc">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Reflejo Tusígeno</label>
                                <select class="form-select" name="reflejo_tusigeno">
                                    <option value="">Seleccionar...</option>
                                    <option value="Presente">Presente</option>
                                    <option value="Ausente">Ausente</option>
                                    <option value="Disminuido">Disminuido</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Reflejo Deglutorio</label>
                                <select class="form-select" name="reflejo_deglutorio">
                                    <option value="">Seleccionar...</option>
                                    <option value="Presente">Presente</option>
                                    <option value="Ausente">Ausente</option>
                                    <option value="Disminuido">Disminuido</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Mucosas</label>
                                <select class="form-select" name="mucosas">
                                    <option value="">Seleccionar...</option>
                                    <option value="Rosadas">Rosadas</option>
                                    <option value="Pálidas">Pálidas</option>
                                    <option value="Ictéricas">Ictéricas</option>
                                    <option value="Cianóticas">Cianóticas</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Temperatura (°C)</label>
                                <input type="text" class="form-control" name="temperatura">
                            </div>
                            <div class="col-md-8">
                                <label class="form-label">Nódulos Linfáticos</label>
                                <input type="text" class="form-control" name="nodulos_linfaticos" placeholder="Especificar ganglios palpables">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección 5: Datos Quirúrgicos -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">5. Datos Quirúrgicos</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Plan Anestésico*</label>
                                <select class="form-select" name="plan_anestesico" required>
                                    <option value="">Seleccionar...</option>
                                    <option value="Intramuscular">Intramuscular</option>
                                    <option value="Intravenoso">Intravenoso</option>
                                    <option value="Inhalatorio">Inhalatorio</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Medicación Preoperatoria</label>
                                <input type="text" class="form-control" name="medicacion_previa">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Observaciones Quirúrgicas</label>
                                <textarea class="form-control" name="observaciones_quirurgicas" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sección 6: Postoperatorio -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">6. Cuidados Postoperatorios</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Cuidados Postoperatorios</label>
                            <textarea class="form-control" name="cuidados_postoperatorios" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Medicación Postoperatoria</label>
                            <textarea class="form-control" name="medicacion_postoperatoria" rows="3"></textarea>
                        </div>
                    </div>
                </div>

                <!-- Botones de acción -->
                <div class="d-flex justify-content-end gap-2">
                    <a href="<?= BASE_URL ?>/salud/salud_animal.php?id=<?= $id_mascota ?>" class="btn btn-cancelar">
                        <i class="fas fa-times me-1"></i> Cancelar
                    </a>
                    <button type="submit" name="guardar_sin_firmar" class="btn btn-outline-purple">
                        <i class="fas fa-save me-1"></i> Guardar sin firmar
                    </button>
                    <button type="submit" name="guardar_y_firmar" class="btn btn-purple">
                        <i class="fas fa-signature me-1"></i> Guardar y Firmar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    :root {
        --color-primario: #8b0180;
        --color-secundario: #6a015f;
        --color-terciario: #f8f1f8;
    }

    .bg-purple { background-color: var(--color-primario); }
    .text-purple { color: var(--color-primario); }
    .border-purple { border-color: var(--color-primario) !important; }
    .btn-purple { 
        background-color: var(--color-primario); 
        color: white;
        border: none;
    }
    .btn-purple:hover {
        background-color: var(--color-secundario);
        color: white;
    }
    .btn-outline-purple {
        color: var(--color-primario);
        border-color: var(--color-primario);
    }
    .btn-outline-purple:hover {
        background-color: var(--color-primario);
        color: white;
    }
    .btn-cancelar {
        background-color: #dc3545;
        color: white;
        border: none;
    }
    .btn-cancelar:hover {
        background-color: #b02a37;
    }
    .info-label {
        font-weight: 500;
        color: #6c757d;
        margin-bottom: 0.25rem;
    }
    .info-value {
        font-size: 1rem;
        margin-bottom: 1rem;
        padding: 0.5rem;
        background-color: #f8f9fa;
        border-radius: 4px;
        border-left: 3px solid var(--color-primario);
    }
    .form-check-input:checked {
        background-color: var(--color-primario);
        border-color: var(--color-primario);
    }
</style>

<?php include(BASE_PATH . '/includes/footer.php'); ?>