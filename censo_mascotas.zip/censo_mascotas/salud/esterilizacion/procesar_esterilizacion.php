<?php
require_once __DIR__ . '/../../config.php';
require_once BASE_PATH . '/database/conexion.php';
require_once BASE_PATH . '/includes/funciones.php';

// Validar ID de mascota y tutor
$id_mascota = isset($_POST['id_mascota']) ? intval($_POST['id_mascota']) : 0;
$id_tutor = isset($_POST['id_tutor']) ? intval($_POST['id_tutor']) : 0;
if ($id_mascota <= 0 || $id_tutor <= 0) {
    redirigir_con_mensaje('buscar.php', 'danger', 'Datos incompletos');
}

// Recoger y sanitizar datos
$_SESSION['form_data'] = $_POST; // Para recuperar en caso de error

$datos = [
    'id_mascota' => $id_mascota,
    'id_tutor' => $id_tutor,
    'fecha_procedimiento' => $_POST['fecha_procedimiento'],
    'hora_procedimiento' => $_POST['hora_procedimiento'],
    'tipo_procedimiento' => sanitizar_input($_POST['tipo_procedimiento']),
    'responsable' => sanitizar_input($_POST['responsable']),
    'localidad' => sanitizar_input($_POST['localidad']),
    
    // Prequirúrgicos
    'vacunacion_rabia' => isset($_POST['vacunacion_rabia']) ? 1 : 0,
    'vacunacion_basica' => isset($_POST['vacunacion_basica']) ? 1 : 0,
    'desparasitacion_producto' => isset($_POST['desparasitacion_producto']) ? sanitizar_input($_POST['desparasitacion_producto']) : null,
    'desparasitacion_fecha' => isset($_POST['desparasitacion_fecha']) ? $_POST['desparasitacion_fecha'] : null,
    'antecedentes' => isset($_POST['antecedentes']) ? sanitizar_input($_POST['antecedentes']) : null,
    
    // Constantes fisiológicas
    'fr_respiratoria' => isset($_POST['fr_respiratoria']) ? sanitizar_input($_POST['fr_respiratoria']) : null,
    'fc_cardiaca' => isset($_POST['fc_cardiaca']) ? sanitizar_input($_POST['fc_cardiaca']) : null,
    'cc_capilar' => isset($_POST['cc_capilar']) ? sanitizar_input($_POST['cc_capilar']) : null,
    'tllc' => isset($_POST['tllc']) ? sanitizar_input($_POST['tllc']) : null,
    'reflejo_tusigeno' => isset($_POST['reflejo_tusigeno']) ? sanitizar_input($_POST['reflejo_tusigeno']) : null,
    'reflejo_deglutorio' => isset($_POST['reflejo_deglutorio']) ? sanitizar_input($_POST['reflejo_deglutorio']) : null,
    'mucosas' => isset($_POST['mucosas']) ? sanitizar_input($_POST['mucosas']) : null,
    'temperatura' => isset($_POST['temperatura']) ? floatval($_POST['temperatura']) : null,
    'nodulos_linfaticos' => isset($_POST['nodulos_linfaticos']) ? sanitizar_input($_POST['nodulos_linfaticos']) : null,
    
    // Quirúrgicos
    'plan_anestesico' => isset($_POST['plan_anestesico']) ? sanitizar_input($_POST['plan_anestesico']) : null,
    'medicacion_previa' => isset($_POST['medicacion_previa']) ? sanitizar_input($_POST['medicacion_previa']) : null,
    'observaciones_quirurgicas' => isset($_POST['observaciones_quirurgicas']) ? sanitizar_input($_POST['observaciones_quirurgicas']) : null,
    
    // Postoperatorio
    'cuidados_postoperatorios' => isset($_POST['cuidados_postoperatorios']) ? sanitizar_input($_POST['cuidados_postoperatorios']) : null,
    'medicacion_postoperatoria' => isset($_POST['medicacion_postoperatoria']) ? sanitizar_input($_POST['medicacion_postoperatoria']) : null
];

try {
    // Preparar la consulta SQL
    $campos = implode(', ', array_keys($datos));
    $placeholders = implode(', ', array_fill(0, count($datos), '?'));
    $tipos = str_repeat('s', count($datos));
    
    $stmt = $conn->prepare("INSERT INTO esterilizaciones ($campos) VALUES ($placeholders)");
    
    // Vincular parámetros dinámicamente
    $valores = array_values($datos);
    $stmt->bind_param($tipos, ...$valores);
    
    if (!$stmt->execute()) {
        throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
    }
    
    $id_esterilizacion = $stmt->insert_id;
    $stmt->close();
    
    // Actualizar estado de esterilización en la mascota
    $stmt_mascota = $conn->prepare("UPDATE mascotas SET esterilizado = 1 WHERE id_mascota = ?");
    $stmt_mascota->bind_param("i", $id_mascota);
    $stmt_mascota->execute();
    $stmt_mascota->close();
    
    // Redirección según si se necesita firma
    if (isset($_POST['guardar_y_firmar'])) {
        $_SESSION['temp_data'] = [
            'tipo' => 'consentimiento_esterilizacion',
            'id_mascota' => $id_mascota,
            'id_esterilizacion' => $id_esterilizacion
        ];
        
        redirigir_con_mensaje(
            'salud/firma_digital.php',
            'success',
            'Esterilización registrada, ahora puede firmar el consentimiento'
        );
    } else {
        unset($_SESSION['form_data']);
        redirigir_con_mensaje(
            "salud/esterilizacion/ver_detalles_esterilizacion.php?id=$id_esterilizacion",
            'success',
            'Esterilización registrada correctamente'
        );
    }
    
} catch (Exception $e) {
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
    
    registrar_error($e->getMessage());
    redirigir_con_mensaje(
        "salud/esterilizacion/esterilizacion.php?id=$id_mascota",
        'danger',
        'Error al registrar la esterilización: ' . $e->getMessage()
    );
}